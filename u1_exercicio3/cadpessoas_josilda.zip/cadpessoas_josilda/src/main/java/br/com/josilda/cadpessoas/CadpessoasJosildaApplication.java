package br.com.josilda.cadpessoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadpessoasJosildaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadpessoasJosildaApplication.class, args);
	}

}
